export default {
  stagePropagationStopped: {}
}
